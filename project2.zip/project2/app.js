const express = require('express');
const app = express();
app.use(express.urlencoded({extended:false}));
const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/portfolio');

const session  = require('express-session');
app.use(session({
    secret:'321',
    resave:false,
    saveUninitialized:false
}))

const router = require('./router/pro');
app.use(router); 

app.use(express.static('public'));
app.set('view engine','ejs');
app.listen(4800);