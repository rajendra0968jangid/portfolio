const mongoose = require('mongoose');
const skillsData = mongoose.Schema({
    title:String,
    name1:String,
    html:Number,

    name2:String,
    css:Number,

    name3:String,
    javascript:Number,

    name4:String,
    node:Number,

    name5:String,
    mongodb:Number,

    name6:String,
    bootstrap:Number
})

module.exports=mongoose.model('skillsData',skillsData);