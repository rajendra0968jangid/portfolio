const mongoose = require('mongoose');
const contactData = mongoose.Schema({
    title:String,
    location:String,
    email:String,                                                           
    call:Number
})

module.exports=mongoose.model('contactData',contactData);