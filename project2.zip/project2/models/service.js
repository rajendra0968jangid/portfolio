const mongoose = require('mongoose');
const serviceData = mongoose.Schema({
    title:String,
    heading1:String,
        heading1Title:String,
    heading2:String,
        heading2Title:String,
    heading3:String,
        heading3Title:String,
    heading4:String,
        heading4Title:String,
    heading5:String,
        heading5Title:String,
    heading6:String,
        heading6Title:String
})

module.exports=mongoose.model('serviceData',serviceData);