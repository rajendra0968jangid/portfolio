const mongoose = require('mongoose');
const resumeData = mongoose.Schema({
    title:String,

    head1:String,
        sub1Head1:String,
            sub1Head1Title:String,
            sub1Head1Point1:String,
            sub1Head1Point2:String,
            sub1Head1Point3:String,

    head2:String,
        sub1Head2:String,
            sub1Head2Date:String,
            sub1Head2Add:String,
            sub1Head2Title:String,
        sub2Head2:String,
            sub2Head2Date:String,
            sub2Head2Add:String,
            sub2Head2Title:String,

    head3:String,
        sub1Head3:String,
            sub1Head3Date:String,
            sub1Head3Add:String,
            sub1Head3Point1:String,
            sub1Head3Point2:String,
            sub1Head3Point3:String,
            sub1Head3Point4:String,
        sub2Head3:String,
            sub2Head3Date:String,
            sub2Head3Add:String,
            sub2Head3Point1:String,
            sub2Head3Point2:String,
            sub2Head3Point3:String,
            sub2Head3Point4:String,
})

module.exports=mongoose.model('resumeData',resumeData);