const mongoose = require('mongoose');
const homeData = mongoose.Schema({
    name:String,
    para:String,
    item:String
})

module.exports=mongoose.model('homeData',homeData);