const mongoose = require('mongoose');
const aboutData = mongoose.Schema({
    title:String,
    heading:String,
    desc:String,
    birthdate:String,
    website:String,
    phone:Number,
    city:String,
    age:Number,
    degree:String,
    email:String,
    freelance:String,
    title2:String,
    image:String
})

module.exports=mongoose.model('aboutData',aboutData);