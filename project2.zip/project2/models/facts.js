const mongoose = require('mongoose');
const factsData = mongoose.Schema({
    title:String,

    num1:Number,
    heading1:String,
    para1:String,

    num2:Number,
    heading2:String,
    para2:String,

    num3:Number,
    heading3:String,
    para3:String,

    num4:Number,
    heading4:String,
    para4:String
})

module.exports=mongoose.model('factsData',factsData);