const mongoose = require('mongoose');
const testimonialsData = mongoose.Schema({
    title:String,

        title1:String,
        name1:String,
        post1:String,

        title2:String,
        name2:String,
        post2:String,

        title3:String,
        name3:String,
        post3:String,

        title4:String,
        name4:String,
        post4:String,

        title5:String,
        name5:String,
        post5:String,
})

module.exports=mongoose.model('testimonialsData',testimonialsData);