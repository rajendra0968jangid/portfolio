const mongoose = require('mongoose');
const portfolioData = mongoose.Schema({
    title:String
})

module.exports=mongoose.model('portfolioData',portfolioData);