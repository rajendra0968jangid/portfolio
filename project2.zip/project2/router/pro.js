const router = require('express').Router();
const adminData = require('../models/admin');
const aboutData = require('../models/about');
const skillsData = require('../models/skills');
const factsData = require('../models/facts');
const resumeData = require('../models/resume');
const serviceData = require('../models/service');
const testimonialsData = require('../models/testimonials');
const homeData = require('../models/home');
const contactData = require('../models/contact');
const portfolioData = require('../models/portfolio');
const bcrypt = require('bcrypt');
const multer = require('multer');
const path = require('path');

var storage = multer.diskStorage({
    destination:"./public/assets/img/",
    filename:(req,file,cb)=>{
        cb(null,file.fieldname+"_1"+path.extname(file.originalname));
    }
});

var uploads = multer({
    storage:storage
}).single('file');

function seq(req,res,next){
    if(req.session.isAuth){
        next();
    }
    else{
        res.redirect('/admin');
    }
}

router.get('/test',async(req,res)=>{
    const password = '123';
    const  salt = await bcrypt.hash(password,10);
    const data = await adminData({username:'rajendra',password:salt});
    data.save();
})

router.get('/',async(req,res)=>{
    const data = await aboutData.find();
    const data1 = await skillsData.find();
    const data2 = await factsData.find();
    const data3 = await resumeData.find();
    const data4 = await serviceData.find();
    const data5 = await testimonialsData.find();
    const data6 = await homeData.find();
    const data7 = await contactData.find();
    const data8 = await portfolioData.find();
    res.render('./index.ejs',{about:data,skills:data1,facts:data2,resume:data3,service:data4,testimonials:data5,home:data6,contact:data7,portfolio:data8});
})

router.get('/admin',(req,res)=>{
    res.render('./html/admin.ejs',{mess:''});
})

router.post('/admin',async(req,res)=>{
    const {uname,password} = req.body;
    const data = await adminData.findOne({username:uname});
    if(data != null){
        if(bcrypt.compareSync(password,data.password)){
            req.session.isAuth=true;
            res.redirect('/adminpanel');
        }
        else{
            res.render('./html/admin.ejs',{mess:'wrong username and password'});
        }
    }
    else{
        res.render('./html/admin.ejs',{mess:'wrong username and password'});
    }
})

router.get('/adminpanel',seq,async(req,res)=>{
    const data = await aboutData.findOne();
    const data1 = await skillsData.findOne();
    const data2 = await factsData.findOne();
    const data3 = await resumeData.findOne();
    const data4 = await serviceData.findOne();
    const data5 = await testimonialsData.findOne();
    const data6 = await homeData.findOne();
    const data7 = await contactData.findOne();
    const data8 = await portfolioData.findOne();
    res.render('./html/adminpanel.ejs',{aboutId:data.id,skillsId:data1.id,factsId:data2.id,resumeId:data3.id,serviceId:data4.id,testimonialsId:data5.id,homeId:data6.id,contactId:data7.id,portfolioId:data8.id});
})

router.get('/about/:id',seq,async(req,res)=>{
    const data = await aboutData.find();
    res.render('./html/about.ejs',{detail:data});
})

router.post('/about/:id',uploads,async(req,res)=>{
    const id = req.params.id;
    const {title,heading,desc,birthdate,website,phone,city,age,degree,email,freelance,title2} = req.body;
    await aboutData.findByIdAndUpdate(id,{title:title,heading:heading,desc:desc,birthdate:birthdate,website:website,phone:phone,city:city,age:age,degree:degree,email:email,freelance:freelance,title2:title2,image:req.file.filename});
    res.redirect('/adminpanel');
})

router.get('/skills/:id',seq,async(req,res)=>{
    const data = await skillsData.find();
    res.render('./html/skills.ejs',{detail:data});
})

router.post('/skills/:id',async(req,res)=>{
    const id = req.params.id;
    const {title,name1,html,name2,css,name3,javascript,name4,node,name5,mongodb,name6,bootstrap} = req.body;
    await skillsData.findByIdAndUpdate(id,{title:title,name1:name1,html:html,name2:name2,css:css,name3:name3,javascript:javascript,name4:name4,node:node,name5:name5,mongodb:mongodb,name6:name6,bootstrap:bootstrap});
    res.redirect('/adminpanel');
})

router.get('/facts/:id',seq,async(req,res)=>{
    const data = await factsData.find();
    res.render('./html/facts.ejs',{facts:data});
})

router.post('/facts/:id',async(req,res)=>{
    const id = req.params.id;
    const {title,num1,heading1,para1,num2,heading2,para2,num3,heading3,para3,num4,heading4,para4} = req.body;
    await factsData.findByIdAndUpdate(id,{title:title,num1:num1,heading1:heading1,para1:para1,num2:num2,heading2:heading2,para2:para2,num3:num3,heading3:heading3,para3:para3,num4:num4,heading4:heading4,para4:para4});
    res.redirect('/adminpanel');
})

router.get('/resume/:id',seq,async(req,res)=>{
    const data = await resumeData.find();
    res.render('./html/resume.ejs',{resume:data});
})

router.post('/resume/:id',async(req,res)=>{
    const id = req.params.id;
    const {title,head1,sub1Head1,sub1Head1Title,sub1Head1Point1,sub1Head1Point2,sub1Head1Point3,head2,sub1Head2,sub1Head2Date,sub1Head2Add,sub1Head2Title,sub2Head2,sub2Head2Date,sub2Head2Add,sub2Head2Title,head3,sub1Head3,sub1Head3Date,sub1Head3Add,sub1Head3Point1,sub1Head3Point2,sub1Head3Point3,sub1Head3Point4,sub2Head3,sub2Head3Date,sub2Head3Add,sub2Head3Point1,sub2Head3Point2,sub2Head3Point3,sub2Head3Point4} = req.body;
    await resumeData.findByIdAndUpdate(id,{title:title,head1:head1,sub1Head1:sub1Head1,sub1Head1Title:sub1Head1Title,sub1Head1Point1:sub1Head1Point1,sub1Head1Point2:sub1Head1Point2,sub1Head1Point3:sub1Head1Point3,head2:head2,sub1Head2:sub1Head2,sub1Head2Date:sub1Head2Date,sub1Head2Add:sub1Head2Add,sub1Head2Title:sub1Head2Title,sub2Head2:sub2Head2,sub2Head2Date:sub2Head2Date,sub2Head2Add:sub2Head2Add,sub2Head2Title:sub2Head2Title,head3:head3,sub1Head3:sub1Head3,sub1Head3Date:sub1Head3Date,sub1Head3Add:sub1Head3Add,sub1Head3Point1:sub1Head3Point1,sub1Head3Point2:sub1Head3Point2,sub1Head3Point3:sub1Head3Point3,sub1Head3Point4:sub1Head3Point4,sub2Head3:sub2Head3,sub2Head3Date:sub2Head3Date,sub2Head3Add:sub2Head3Add,sub2Head3Point1:sub2Head3Point1,sub2Head3Point2:sub2Head3Point2,sub2Head3Point3:sub2Head3Point3,sub2Head3Point4:sub2Head3Point4})
    res.redirect('/adminpanel');
})

router.get('/service/:id',seq,async(req,res)=>{
    const data = await serviceData.find();
    res.render('./html/service.ejs',{service:data});
})

router.post('/service/:id',async(req,res)=>{
    const id = req.params.id;
    const {title,heading1,heading1Title,heading2,heading2Title,heading3,heading3Title,heading4,heading4Title,heading5,heading5Title,heading6,heading6Title} = req.body;
    await serviceData.findByIdAndUpdate(id,{title:title,heading1:heading1,heading1Title:heading1Title,heading2:heading2,heading2Title:heading2Title,heading3:heading3,heading3Title:heading3Title,heading4:heading4,heading4Title:heading4Title,heading5:heading5,heading5Title:heading5Title,heading6:heading6,heading6Title:heading6Title})
res.redirect('/adminpanel');
})

router.get('/testimonials/:id',seq,async(req,res)=>{
    const data = await testimonialsData.find();
    res.render('./html/testimonials.ejs',{testimonials:data});
})

router.post('/testimonials/:id',async(req,res)=>{
    const id = req.params.id;
    const {title,title1,name1,post1,title2,name2,post2,title3,name3,post3,title4,name4,post4,title5,name5,post5} = req.body;
    await testimonialsData.findByIdAndUpdate(id,{title:title,title1:title1,name1:name1,post1:post1,title2:title2,name2:name2,post2:post2,title3:title3,name3:name3,post3:post3,title4:title4,name4:name4,post4:post4,title5:title5,name5:name5,post5:post5});
})

router.get('/home/:id',seq,async(req,res)=>{
    const data = await homeData.find();
    res.render('./html/home.ejs',{home:data});
})

router.post('/home/:id',async(req,res)=>{
    const id = req.params.id;
    const {name,para,item} = req.body;
    await homeData.findByIdAndUpdate(id,{name:name,para:para,item:item});
    res.redirect('/adminpanel');
})

router.get('/contact/:id',seq,async(req,res)=>{
    const data = await contactData.find();
    res.render('./html/contact.ejs',{contact:data});
})

router.post('/contact/:id',async(req,res)=>{
    const id = req.params.id;
    const {title,location,email,call} = req.body;
    await contactData.findByIdAndUpdate(id,{title:title,location:location,email:email,call:call});
    res.redirect('/adminpanel');
})

router.get('/portfolio/:id',seq,async(req,res)=>{
    const data = await portfolioData.find();
    res.render('./html/portfolio.ejs',{portfolio:data});
})

router.post('/portfolio/:id',async(req,res)=>{
    const id = req.params.id;
    await portfolioData.findByIdAndUpdate(id,{title:req.body.title});
    res.redirect('/adminpanel');
})
module.exports=router;